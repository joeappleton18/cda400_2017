#Weekly Task - Make a SEO friendly website 

