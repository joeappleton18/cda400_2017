#Week 4 - Welcome to the fourth week

By the end of this week, you should have an understanding of:


- How to apply pseudo classes to elements  
- How to layout HTML pages using floats
