#Session 8 Lecturer Notes

##Assessment 1 Announcement  0 - 10 mins
The hand in link for assessment 1 is now live, spend some time going over the hand in process. **Note** there's also a submission guide that's live on myCourse, you should briefly go over this. **This is the last task that will have to be referenced in the learning log**


##Introduce the importance of usable forms 10- 15 mins
Encourage the students to work along with you. Grab the source code for the unusable form demo (link on page 3). It's worth mentioning that most form elements are inline. 



##Introduce wire frames 15-20 mins
We're going to go through the process of turning an unusable form into something that resembles the wire frame. 

## \<fieldset> and \<legend> elements 15-30 mins
Show how to group together form elements using `<fieldset>` and `<legend>`. I showed the students one example and got the to complete the form.   

## \<p> tags  can be used to create separate lines 30-35 mins
Get the students to place the inputs and their associated labels on new lines using `<p>` tags. 


## CSS for Forms  35-50 mins 
As per the notes, complete the form layout using the CSS techniques mentioned.

## Kick of the task for the week 50 mins +++ 










 