var gulp = require('gulp');
var changed = require('gulp-changed');

var SRC = '/Users/joeappleton1/Dropbox/screenshots/*png'
var DEST = 

gulp.task('default', function() {

    console.log('hello world');
});