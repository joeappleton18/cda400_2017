
##Planning 

- Wire frame planning
 
 >> - Good 
 
##Overall site quality

- HTML 
>> - Good 

- overall user experience  
>> - Good  
 
##index.html
 
 
- page laid out as per specification **(core)** 

	>> - Good 
	
- basic javascript clock created **(core)**

	>> - Good 
	
- dynamic javascript features added to the page **(intermediate)**

	>> - Good 

-  javascript Carousel created **(advanced)** 

	>> - Good 
	
##contact.html

- map embedded into page **(core)**		

>> - Good 

- form created as per spec **(core)**

>> - Good 	

- basic javascript validation added to the form  **(core)**

>> - Good 

- real time form validation added **(intermediate)**

>> - Good 

- cross or tick shown on form **(advanced)** 

>> - Good


##order.html

- order form laid out correctly **(core)**

>> - Good 
 

- validation added to oder from **(core)**

>> - Good 
 

- realtime price information shown **(intermediate)**

>> - Good 

- additional toppings added **(advanced)**

>> - Good 

- real time order summary displayed **(advanced plus)** 










